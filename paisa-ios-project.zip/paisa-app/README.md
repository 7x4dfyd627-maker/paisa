# Paisa — build the iOS app

One-time setup on your Mac (needs Xcode + Node.js, same as Hearth & Ledger):

1. Copy this folder to your Mac and open Terminal inside it
2. `npm install`
3. `npx cap add ios`
4. `npm run icons`        ← generates all iOS icon sizes from assets/icon.png
5. `npx cap open ios`     ← opens Xcode
6. In Xcode: select your Team under Signing & Capabilities, choose your iPhone, press Run

## Updating the app later
When you get an updated index.html, replace `www/index.html`, then:
`npx cap sync ios` and Run again from Xcode.

## Notes
- All data is stored on the phone. Use Settings → "Back up data (JSON)" before deleting/reinstalling the app.
- PDF statement import downloads the pdf.js reader on first use (needs internet once); CSV import is fully offline.
- "Update rates online" fetches live exchange rates; you can also edit rates manually in Settings.
